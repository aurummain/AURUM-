# The script commands Specific for the project
yarn install
yarn run lint
yarn run build
yarn run build:mobile
yarn run test:unit