#!/bin/bash

set -e

echo "Install Script"

npm install
npm prune
