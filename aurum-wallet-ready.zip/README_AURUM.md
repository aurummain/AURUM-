# AURUM Wallet — готовая сборка брендинга

Этот форк `whitelabelwallet` настроен под токен **AURUM** и золотую тему.

## Запуск локально
```bash
npm install
npm start
```
Откроется dev-сервер (обычно http://localhost:3000 или как указано в README проекта).

## Сборка production
```bash
npm run build
```
Файлы окажутся в `build/`.

## Деплой (3 простых варианта)
1) **Vercel**: импортируйте репозиторий, Build Command: `npm run build`, Output Dir: `build/`  
2) **Netlify**: New site from Git → Build: `npm run build`, Publish directory: `build/`  
3) **Nginx**: скопируйте содержимое `build/` на сервер и настройте виртуальный хост.

## Где менять под себя
- Название и продукт: `package.json` (name, productName)
- Мобильное имя: `capacitor.config.json` (appName, appId)
- Токены: `src/config/tokens.js`
- Цвета: `src/styles/colors.scss`
- Логотип: `src/assets/aurum-logo.svg`

> Примечание: исходный проект кросс‑платформенный (Electron/Capacitor). Для сборки десктопных/мобильных приложений см. оригинальный `README.md`.
